
long get_syndrome(long pattern);
long arr2int(int a[], int r);
void nextcomb(int n, int r, int a[]);

